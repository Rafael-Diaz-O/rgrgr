package pelicula;


public class Personaje {
    
    private String nombre; 
    private String tipodepersonaje; 
    private int edad; 
    
    
    public Personaje (String nombre , String tipodepersonaje, 
            int edad) {
        this.setNombre(nombre) ; 
        this.setTipodepersonaje(tipodepersonaje);
        this.setEdad(edad); 
    }
    
    public void setNombre (String nombre){
        if (nombre == null || nombre.isBlank() || nombre.matches(".*[-!@#$%^()+=<>?/].*")){
            throw new IllegalArgumentException("Nombre del personaje no valido"); 
        } else {
            this.nombre = nombre; 
        }
    }
    
    public void setTipodepersonaje (String tipodepersonaje){
        if (tipodepersonaje == null || tipodepersonaje.isBlank() || tipodepersonaje.matches(".*[-!@#$%^()+=<>?/].*")){
            throw new IllegalArgumentException("El tipo de personaje no valido"); 
        } else {
            this.tipodepersonaje = tipodepersonaje; 
        }
    }
    
    public void setEdad (int edad){
        if ( edad < 0 || edad > 150 ){
            throw new IllegalArgumentException("La edad del personaje no es valida: "); 
        } else {
            this.edad = edad; 
        }
    }
    
    @Override 
    public String toString(){
        
        String mensaje = "Nombre: " + this.nombre+ "\n Tipo de personaje:  " +
                this.tipodepersonaje+ "\n Edad: " + this.edad;
        
        return mensaje; 
    }
        
}
