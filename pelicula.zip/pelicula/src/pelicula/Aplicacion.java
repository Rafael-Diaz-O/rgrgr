package pelicula;

import java.util.Scanner; 

public class Aplicacion {

    
    
     /* public static Busqueda datos (String genero,String nombre, int año,
            double tiempo,String idioma){

        Busqueda usuario = new Busqueda();
        
        try {
        usuario.setGeneroPeli(genero);
    } catch (Exception e) {
        System.out.println("Error al establecer el género: " + e.getMessage());
    }
        try {
        usuario.setNombredePeli(nombre);
    } catch (Exception e) {
        System.out.println("Error al establecer el nombre: " + e.getMessage());
    }
       
        usuario.setAñoPublicacion(año);
        usuario.setTiempoduracion(tiempo);
    
        try {
        usuario.setIdiomaPeli(idioma);
    } catch (Exception e) {
        System.out.println("Error al establecer el idioma: " + e.getMessage());
    }  
        
        return usuario; 
        
        
    }
    */
    
    

    
    public static void main(String[] args) {
        
        Scanner info = new Scanner (System.in);
        Personaje personaje1 = null;
        boolean objectocreado = false;
        
        //crear el objecto eprsonaje 
        
        while (!objectocreado){
            try {
                
                System.out.println("Cual es el nombre del personaje: ");
                String nombre = info.nextLine(); 
                
                System.out.println("Que tipo de personaje es: ");
                String tipodepersonaje = info.nextLine(); 
                
                System.out.println("Cuantos años tiene el personaje: ");
                int edad = info.nextInt(); 
                
                personaje1 = new Personaje (nombre,tipodepersonaje,edad);
                System.out.println("Se creo el objecto personaje: ");
                objectocreado = true; 
                
            }catch(IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
            
            System.out.println("La informacion del personaje es \n " + personaje1.toString());
        }
        
        
        /* String genero, nombre,idioma;
        int año;
        double tiempo; 
        
        for (int i=0 ;  i<2; i++){
        Scanner teclado = new Scanner (System.in);
        
        
        System.out.print("Cual es el genero de la pelicula: ");
        genero = teclado.nextLine(); 
        
        System.out.println("Cual es el nombre de la pelicula: ");
        nombre = teclado.nextLine(); 
        
        System.out.print("En que año se publico la pelicula: ");
        año = teclado.nextInt();
        
        System.out.println("Cuanto dura la pelicula en minutos: ");
        tiempo = teclado.nextDouble(); 
        
        System.out.println("Cual es el idioma original de la pelicula: ");
        idioma = teclado.nextLine(); 
        
        //datos (genero,nombre,año,tiempo,idioma);
        
        Busqueda usuario = datos(genero,nombre,año,tiempo,idioma);
        //En usuario estoy es reescribiendo el codigo

        System.out.println(usuario.toString());
        } 
         
    }
    */ 
        
            
        
}
    
    
}