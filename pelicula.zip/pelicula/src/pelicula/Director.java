
package pelicula;


public class Director {
    
    private int edad ;
    private String nombre;
    private String estudio; 
    
}


