package pelicula;


public class Director {
    
    // Atributos 
    
    private  String nombre; 
    private int edad;
    private String estudio; 
    
    public String getnombre(){
        return this.nombre; 
    }
    
    public int getedad(){
        return this.edad;
    }
    
    public String getestudio(){
        return this.estudio; 
    }
    
    
}
