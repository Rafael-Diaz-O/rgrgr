package pelicula;

public class Busqueda {
    
    private String  generodePelicula;
    private String NombredePelicula;
    private int añodePublicacion;
    private double Tiempodeduracion;
    private String IdiomadePelicula;
    
    public void  setGeneroPeli (String genero) throws Exception {
        if (genero.isBlank()){
            System.out.println("Sejo");
            throw new Exception(); 
        } 
        else {
            if (!genero.matches("^[a-zA-Z ]+$ *")){
            System.out.println("Sejo");
            throw new Exception();
            }else{
                this.generodePelicula  = genero ;
            }
        
                }
   }
    
    
    
public void  setAñoPublicacion (int año)  {
   this.añodePublicacion = año; 
    }
   
  public void  setTiempoduracion (double tiempo){
        this.Tiempodeduracion = tiempo;             
   }
    public void  setIdiomaPeli (String idioma) throws Exception {
        if (idioma.isBlank()){
            System.out.println("Sejo");
            throw new Exception(); 
        }
        else{ if (!idioma.matches("^[a-zA-Z ]+$ *")){
            System.out.println("Sejo");
            throw new Exception();
            }else{
        
           this.IdiomadePelicula = idioma; 
                }
     }
    }

    public void  setNombredePeli (String nombre) throws Exception {
        if (nombre.isBlank()){
            System.out.println("Sejo");
            throw new Exception(); 
        }
        else {
        this.NombredePelicula = nombre; 
                }
   }
   
   public String getGenerodePelicula( ){
           
       return this.generodePelicula;  
    }
   
   public String getNombredePelicula ( ){
       return this.NombredePelicula;
   }
   
   public int getañodePublicacion (){
       return this.añodePublicacion;
   }
   
   public double getTiempodeduracion ( ){
       return this.Tiempodeduracion;
   }
   
   public String getIdiomadePelicula ( ){
       return this.IdiomadePelicula;
   }
   
    @Override
   public String toString(){
       String user = "Busqueda: " + this.generodePelicula + " "+ this.NombredePelicula+
      " " + this.añodePublicacion + " "+this.Tiempodeduracion+" "+ this.IdiomadePelicula;
       
       return user;
   }
    
}
